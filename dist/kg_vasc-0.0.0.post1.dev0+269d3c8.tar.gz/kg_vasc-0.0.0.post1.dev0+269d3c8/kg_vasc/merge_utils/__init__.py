"""Merge module."""

from .merge_kg import load_and_merge, parse_load_config

__all__ = ["parse_load_config", "load_and_merge"]
