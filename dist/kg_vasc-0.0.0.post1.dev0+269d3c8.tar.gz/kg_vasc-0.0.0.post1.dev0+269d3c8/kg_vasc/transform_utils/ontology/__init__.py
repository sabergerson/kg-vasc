"""Ontology transform module."""

from .ontology_transform import OntologyTransform

__all__ = ["OntologyTransform"]
