"""ROBOT utility."""
